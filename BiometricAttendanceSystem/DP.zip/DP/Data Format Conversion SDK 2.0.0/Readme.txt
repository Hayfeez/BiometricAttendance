-------------------------------------------------------------------

                           DigitalPersona
                     Data Format Conversion SDK

                           Version 2.0.0
                           September 2011
				
      (c) 1996-2011 DigitalPersona, Inc. All Rights Reserved. 
-------------------------------------------------------------------

This document provides late-breaking or other information that supplements the DigitalPersona Data Format Conversion SDK documentation.


-------------------------
How to Use This Document
-------------------------

To view the Readme file on-screen in Windows Notepad, maximize the Notepad window. On the Format menu, click Word Wrap. To print the Readme file, open it in Notepad or another word processor, and then use the Print command on the File menu.


---------
CONTENTS
---------

1.   INSTALLATION
2.   COMPATIBILITY
3.   SYSTEM REQUIREMENTS
4.   RELEASE NOTES
5.   KNOWN ISSUES      
6.   dpcnConvert PARAMETERS AND USAGE EXAMPLES
7.   SUPPORT AND FEEDBACK

 
----------------
1. INSTALLATION
----------------

You must have local administrator rights to install this product on supported Windows systems.

Data Format Conversion SDK 2.0.0
1- Open/load the Data Format Conversion product package
2- Run Setup.exe located in the SDK folder
3- Follow the installation instructions

Data Format Conversion RTE 2.0.0
1- Open/load the Data Format Conversion product package 
2- Install Setup.exe located in the RTE folder
3- Follow the installation instructions


-----------------
2. COMPATIBILITY
-----------------

Fingerprint templates produced by the Data Format Conversion SDK are compatible with the following DigitalPersona SDKs:

- One Touch for Windows SDK, all editions
- One Touch I.D. SDK
- Gold SDK
- Gold CE SDK
- Platinum SDK
- One Touch for Linux SDK, all distributions


-----------------------
3. SYSTEM REQUIREMENTS
-----------------------

- x86-based processor or better
- CD/DVD drive (for CD-ROM installation)
- One of the following operating systems - Microsoft Windows XP (32/64-bit), Microsoft Windows Vista (32/64-bit), Microsoft Windows Windows 7 (32/64-bit)


-----------------
4. RELEASE NOTES
-----------------

4.1 This product offers the following general features:
- Template conversion to and from ANSI 378 and ISO standards
- Converts "DP custom key" to "DP default key"
- x64 version support
- dpcnConvert.exe command-line conversion utility


4.2 Component list:
- DPCN.dll, DPCN.lib, DPCN_API.h � C API implementation
- DPCN_HELPER.h � C/C++ helper functions
- DigitalPersona.Standards.dll � .NET wrapper
- Sample code for the C API
- jna.jar, standards.jar � Java API implementation
- Source/API � source code for Java API implementation
- Samples/ApiSample � - Sample code for the Java API


----------------
5. KNOWN ISSUES
----------------

There is no support for Unicode for the custom encryption key when provided as a string from the application through the API. However, binary representation (from registry FT_1/FT_2) allows using any custom encryption key.


---------------------------------------------
6. dpcnConvert PARAMETERS AND USAGE EXAMPLES
---------------------------------------------
Data Format Convertion Tool 2.0.0.
Copyright � DigitalPersona, Inc. 2011
Usage: dpcnConvert <Type> <InFormat> <OutFormat> <InFileMask> <OutBaseDir> [<Rotation>] [<Resolution>]
       <Type> is one of the following:
                     t : Templates to be converted;
                     f : Feature Sets to be converted;
                     i : Image Sets to be converted;
       <{In|Out}Format> is one of the following:
                     d : DP OT4W / Gold SDK format
                     p : DP Platinum SDK format (Templates/Feature Sets only)
                     i : ISO/IEC 19794-2 2005 (Templates/Feature Sets) / ISO/IEC 19794-4 2005 (Images) format
                     a : ANSI INCITS 378-2004 (Templates/Feature Sets) / ANSI INCITS 381-2004 (Images) format
                     r : Raw Image format (Out only)
       <InFileMask>: Mask defining input files set; wildcards *, ? are accepted
       <OutBaseDir>: Root Directory where output files will be placed
       <Rotation>:   Rotate:
                     by angle specified in degrees, only applicable to Templates/Feature Sets formats conversion        to/from ISO/ANSI;
                     boolean (1|0) 180 degrees rotation, only applicable to Image formats conversion;
                     Default is 0.
       <Resolution>: New resolution in DPI if image rescaling is desirable with Image formats conversion;
                     0 means keep source resolution (no rescaling); Default is 0
Output file extensions:
                     DP OT4W / Gold SDK Images                    .fdi
                     ISO/IEC 19794-4 2005 Images                  .isi
                     ANSI INCITS 381-2004 Images                  .asi
                     Raw Images                                   .raw
                     DP OT4W / Gold SDK Templates/Feature Sets    .ftr
                     DP Platinum SDK Templates/Feature Sets       .fpt
                     ISO/IEC 19794-2 2005 Templates/Feature Sets  .ist
                     ANSI INCITS 378-2004 Templates/Feature Sets  .ast


Example of template conversion from DP OT4W format to ISO template format:

    dpcnConvert t d i C:\DC\Dir1\Templates\*.* C:\DC\Dir2\DirXa
    dpcnConvert t d i C:\DC\D?r1\Templates\*.ftr C:\DC\Dir2\DirXa                                

Example of feature set conversion from DP OT4W format to ISO template format:

    dpcnConvert f d i C:\DC\Dir1\FeatureSets\*.* C:\DC\Dir2\DirXa                                                                 dpcnConvert f d i C:\DC\D?r1\FeatureSets\*.ftr C:\DC\Dir2\DirXa 

Example of image conversion from DP OT4W format to ISO format:

    dpcnConvert i d i C:\DC\Dir1\FdiImages\*.* C:\DC\Dir2\DirXa                                
    dpcnConvert i d i C:\DC\D?r1\FdiImages\*.fdi C:\DC\Dir2\DirXa 
                                                           

------------------------
7. SUPPORT AND FEEDBACK
------------------------

Technical support is available through the DigitalPersona Developer Connection at www.digitalpersona.com/webforums, where you can search for answers to questions posted by other developers and post your own questions. You can also purchase a Developer Support package at our web store: https://store2.esellerate.net/store/checkout/CustomLayout.aspx?s=STR1045285899&pc=&page=OnePageCatalog.htm

