-------------------------------------------------------------------
                          DigitalPersona

                  One Touch I.D. SDK version 2.2.1 
            
                            Readme File
               
                            August 2010				
-------------------------------------------------------------------
       (c) 2010 DigitalPersona, Inc. All Rights Reserved. 


This document provides late-breaking or other information that supplements the DigitalPersona One Touch I.D. SDK documentation.


-------------------------
How to Use This Document
-------------------------

To view the Readme file on-screen in Windows Notepad, maximize the Notepad window. In the Format menu, click Word Wrap. To print the Readme file, open it in Notepad or another word processor, and then use the Print command on the File menu.


---------
CONTENTS
---------

1.   INSTALLATION

2.   COMPATIBILITY

3.   SYSTEM REQUIREMENTS

4.   RELEASE NOTES

5.   KNOWN ISSUE
     
6.   SUPPORT AND FEEDBACK
 

----------------
1. INSTALLATION
----------------

You must have local administrator rights to install the following products on the supported operating systems:

One Touch I.D. SDK 2.2.1
1- Open/load the One Touch I.D. product package
2- Run Setup.exe located in the SDK folder
3- Follow the installation instructions

One Touch I.D. RTE 2.2.1
1- Open/load the One Touch I.D. product package 
2- Run Setup.exe located in the RTE folder
3- Follow the installation instructions


-----------------
2. COMPATIBILITY
-----------------

DigitalPersona One Touch I.D. SDK version 2.2.1 is compatible with the following DigitalPersona products:
- DigitalPersona Pro Workstation 4.2.0 and later.
- DigitalPersona Pro Kiosk version 4.2.0 and later.


DigitalPersona One Touch I.D. SDK version 2.2.1 is incompatible with any other DigitalPersona product.

For template compatibility, please see the One Touch I.D. SDK Developer Guide.


-----------------------
3. SYSTEM REQUIREMENTS
-----------------------

General System Requirements:

- X86-based processor or better
- CD-ROM drive
- One of the following operating systems - Microsoft Windows XP (32/64-bit), Microsoft Windows XP Embedded (32-bit), Microsoft Windows Vista (32/64-bit), Microsoft Windows 7 (32/64-bit), Microsoft Server 2003/2008 (32/64-bit)
- Microsoft .NET Framework (version 2 or later), which is obtainable from Microsoft
- Administrative privileges
- Microsoft Visual Studio 2005 or later

To determine tha amount of RAM required when creating large identification sets, see the chapter, "Determining Additional Memory Requirements" in the One Touch I.D. SDK Developer Guide.

Product Specific System Requirements:

One Touch I.D. SDK 
- Approximate available hard-disk space 20 MB
- Microsoft Visual Studio 2005 or later

One Touch I.D. RTE
- Approximate available hard-disk space 500 KB

  
-----------------
4. RELEASE NOTES
-----------------

4.1    One Touch I.D. SDK version 2.2.1 supports both single-finger and two-finger identification.

4.2    The new identification engine included with this version has no limitation on the number of templates that can be used for an identification operation.

4.3    One Touch for Windows 1.6.1 RTE components are included in One Touch I.D. RTE 2.2.1 installation as an optional feature. Developers are no longer required to build the sample application before execution.

4.4    One Touch I.D. SDK version 2.2.1 extends identification for templates. This enables the developer to run duplicate enrollment checks over a user collection. A specific support tech bulletin elaborating on this is available through DigitalPersona tech support.

4.5    One Touch I.D. SDK version 2.2.1 also includes the One Touch For Windows .NET documentation and samples, and can be used to implement a full-fledged biometrics product encompassing fingerprint collection, enrollment, and verification. We strongly suggest that One Touch I.D. developers use this embedded version of One Touch for Windows. If you already have One Touch for Windows installed, you will need to uninstall it prior to the installation of One Touch I.D. SDK version 2.2.1.


-----------------
5. KNOWN ISSUE
-----------------

5.1    When creating your own msi installer for 64-bit application using the merge modules, you need to specify separate target directories for 32-bit and 64-bit merge modules.


------------------------
6. SUPPORT AND FEEDBACK
------------------------

If you have suggestions for future product releases or require technical support for your product, visit http://www.digitalpersona.com/developersupport.

For additional product information and software updates, visit the DigitalPersona Web site at http://www.digitalpersona.com.

If you are a DigitalPersona Maintenance and Support customer, please refer to your Maintenance & Support Confirmation email for information on technical support resources available to you.











